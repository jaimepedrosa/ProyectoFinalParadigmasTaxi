using UnityEngine;

public class Taxi : MonoBehaviour
{
    private Rigidbody rb;
    public float speed = 5f;
    public float rotationSpeed = 200f;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        // Input para el movimiento hacia adelante/atr�s
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 forwardMovement = transform.forward * moveVertical * speed;

        // Input para la rotaci�n
        float turn = Input.GetAxis("Horizontal");
        Quaternion turnRotation = Quaternion.Euler(0f, turn * rotationSpeed * Time.deltaTime, 0f); //Crea un cambio de rotaci�n en el eje Y (para girar sobre el plano horizontal) que depende del input horizontal, la velocidad de rotaci�n (rotationSpeed), y Time.deltaTime (para asegurar que el giro sea suave y no dependa de la velocidad de los cuadros).
        rb.MoveRotation(rb.rotation * turnRotation);

        // Aplicamos el movimiento solo en la direcci�n del "frente" del taxi
        Vector3 movement = new Vector3(forwardMovement.x, rb.linearVelocity.y, forwardMovement.z);
        rb.linearVelocity = movement;
    }
}
