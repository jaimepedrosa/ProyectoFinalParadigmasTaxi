using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;


public class PoliceCar : MonoBehaviour
{
    public SpeedRadar speedRadar;
    private NavMeshAgent navMeshagent;
    private Transform playertransform;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void StartPatrolling()
    {
        
    }
    public void StopPatrolling()
    {

    }
    public void StartPersecution()
    {

    }
    void Start()
    {
        navMeshagent = GetComponent<NavMeshAgent>();
        playertransform = FindAnyObjectByType<Taxi>().transform;

    }

    // Update is called once per frame
    void Update()
    {
        if (speedRadar.alert == true)
        {
            navMeshagent.destination = playertransform.position;
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.CompareTag("Taxi"))
        {
            SceneManager.LoadScene(2);

        }
    }

}
